#!/usr/bin/env bash
# 一鍵套用 patch：偵測安裝位置 → 備份 → 覆蓋 → 修 CRLF → 重啟 → 驗證
set -e
cd "$(dirname "$0")"
# 目標安裝根：預設當前目錄的上層(patch 放在安裝根裡執行)，可用參數指定
TARGET="${1:-}"
if [ -z "$TARGET" ]; then
  # 從常見位置猜：離線包解開處 有 app/webvuln；git clone 有 webvuln
  for c in "$PWD" "$PWD/.." "$HOME/CL_WebVuln_installpack" "$HOME/cl_patchweb"; do
    if [ -d "$c/app/webvuln" ] || [ -d "$c/webvuln" ]; then TARGET="$c"; break; fi
  done
fi
[ -n "$TARGET" ] || { echo "找不到安裝目錄，請指定： bash patch.sh /path/to/安裝根"; exit 1; }
# 安裝根底下 app/ 或本身
BASE="$TARGET/app"; [ -d "$BASE/webvuln" ] || BASE="$TARGET"
[ -d "$BASE/webvuln" ] || { echo "「$TARGET」不像安裝目錄(找不到 webvuln/)"; exit 1; }
echo "套用到：$BASE"

TS="$(date +%Y%m%d_%H%M%S)"
BK="$TARGET/patch_backup_$TS"; mkdir -p "$BK"
# files/ 內是相對 APP/ 的路徑
cd files
find . -type f | while read -r f; do
  rel="${f#./}"
  dst="$BASE/$rel"
  if [ -f "$dst" ]; then mkdir -p "$BK/$(dirname "$rel")"; cp -p "$dst" "$BK/$rel"; fi
  mkdir -p "$(dirname "$dst")"
  cp -p "$f" "$dst"
  case "$rel" in
    *.py|*.js|*.html|*.css|*.md|*.sh|*.json|*.txt) sed -i 's/\r$//' "$dst" ;;
  esac
  echo "  ✓ $rel"
done
cd ..
echo "備份在：$BK"

# 重啟服務（有 systemd 服務就重啟；否則提示手動）
SVC="$(systemctl list-units --type=service --all 2>/dev/null | grep -oE 'webvuln[^ ]*\.service' | head -1 || true)"
if [ -n "$SVC" ]; then
  echo "重啟 $SVC"; sudo systemctl restart "$SVC" || systemctl restart "$SVC" || echo "（重啟失敗，請手動 systemctl restart $SVC）"
  sleep 3
else
  echo "未偵測到 systemd 服務。若你是用 run.sh 前景跑，請 Ctrl+C 後重新 bash run.sh。"
  echo "（純前端檔改動不重啟也行，瀏覽器 Ctrl+F5 即可；後端 .py 改動才需重啟）"
fi

# 驗證
PORT="${PORT:-3100}"
if command -v curl >/dev/null; then
  echo -n "驗證 health："; curl -s -m5 "http://127.0.0.1:$PORT/api/health" || echo "（連不到，請確認服務有起來）"; echo
fi
echo "完成。瀏覽器請按 Ctrl+F5 清快取。若要回復：把 $BK 內的檔覆蓋回去即可。"
