#!/usr/bin/env bash
# 一鍵套用 patch —— 在解開的這個資料夾裡執行：
#     sudo bash patch.sh              自動找安裝位置
#     sudo bash patch.sh /安裝位置     找不到或找到不只一個時，自己指定
#
# 它會：找安裝位置 → 驗包 → 備份 → 覆蓋 → 重啟 → 驗證。
# 出事怎麼辦：畫面會印出備份目錄與一行還原指令。
# 可以重跑：同一包重複套用不會壞，只是再備份一次。
set -uo pipefail
umask 022     # root 的 umask 常是 077：新建的目錄會變成只有 root 進得去，服務帳號讀不到

HERE="$(cd "$(dirname "$0")" && pwd)"
TS="$(date +%Y%m%d_%H%M%S)"
MARK='webvuln\.main:app'          # 這個系統的啟動指令一定帶這段，用它認服務與行程

ver_of() { grep -oE "APP_VERSION *= *'V?[0-9.]+'" "$1" 2>/dev/null | grep -oE '[0-9]+(\.[0-9]+)+' | head -1; }
# 給「安裝根」或「app 目錄」都可以，回傳真正放 webvuln/ 的那一層
app_dir_of() {
  local d
  for d in "$1" "$1/app" "$1/APP"; do
    if [ -d "$d/webvuln" ]; then (cd "$d" && pwd -P); return 0; fi
  done
  return 1
}

echo "════════════════════════════════════════════════"
echo " 套用 patch： $(basename "$HERE")"
echo " 時間　　　： $(date '+%F %T')　執行身分： $(id -un)"
echo "════════════════════════════════════════════════"

trap 'echo; echo "!! 中斷了。檔案可能只換了一部分、服務也還沒重啟。"; \
      echo "   請直接再跑一次（這支腳本可以重跑）： bash $0"; exit 130' INT TERM

# ===== 1. 找安裝位置 =====
# 不用猜的：先看 systemd 服務設定、再看正在跑的行程，最後才試常見路徑。
# 找到不只一個就停下來請人指定——套錯地方比沒套更糟。
echo
echo "[1/6] 找安裝位置"
CANDS=""
add_cand() { local r; r="$(app_dir_of "$1" 2>/dev/null)" || return 0
             case "
$CANDS" in *"
$r
"*) : ;; *) CANDS="$CANDS$r
"; echo "  找到 $r（$2）" ;; esac; }

if [ -n "${1:-${WEBVULN_APP:-}}" ]; then
  GIVEN="${1:-$WEBVULN_APP}"
  app_dir_of "$GIVEN" >/dev/null || { echo "!! 「$GIVEN」底下找不到 webvuln/，不是安裝位置"; exit 1; }
  add_cand "$GIVEN" "你指定的"
else
  for u in /etc/systemd/system/*.service; do
    [ -f "$u" ] || continue
    grep -qE "$MARK" "$u" 2>/dev/null || continue
    wd="$(grep -E '^WorkingDirectory=' "$u" | head -1 | cut -d= -f2-)"
    [ -n "$wd" ] && add_cand "$wd" "systemd 服務 $(basename "$u")"
  done
  for pid in $(pgrep -f "[u]vicorn $MARK" 2>/dev/null); do
    wd="$(readlink "/proc/$pid/cwd" 2>/dev/null)" || continue
    [ -n "$wd" ] && add_cand "$wd" "執行中的行程 PID $pid"
  done
  if [ -z "$CANDS" ]; then
    for d in "$HERE/.." "$HOME/CL_WebVuln_installpack" "$HOME/cl_patchweb"; do
      add_cand "$d" "常見路徑"
    done
  fi
fi
NC="$(printf '%s' "$CANDS" | grep -c .)"
if [ "$NC" = "0" ]; then
  echo "!! 找不到安裝位置（沒有 systemd 服務、沒有執行中的行程、常見路徑也沒有）。"
  echo "   請指定： bash patch.sh /安裝位置"
  exit 1
fi
if [ "$NC" != "1" ]; then
  echo "!! 找到不只一個安裝位置，不敢自己挑。請指定要套哪一個： bash patch.sh /安裝位置"
  exit 1
fi
APP="$(printf '%s' "$CANDS" | head -1)"
# 備份與套用紀錄放在 app 的上一層；那一層若是 git 工作區就再往上，不弄髒工作區。
STATE="$(dirname "$APP")"
[ -e "$STATE/.git" ] && STATE="$(dirname "$STATE")"
BACKUP="$STATE/patch_backup_$TS"
HISTORY="$STATE/patch_history.log"

# 服務、帳號、埠：都從現成的設定讀，不寫死
UNIT=""; SVC_USER=""; PORT="${PORT:-}"; RUN_PID=""
for u in /etc/systemd/system/*.service; do
  [ -f "$u" ] || continue
  grep -qE "$MARK" "$u" 2>/dev/null || continue
  wd="$(grep -E '^WorkingDirectory=' "$u" | head -1 | cut -d= -f2-)"
  [ "$(app_dir_of "$wd" 2>/dev/null)" = "$APP" ] || continue
  UNIT="$(basename "$u" .service)"
  SVC_USER="$(grep -E '^User=' "$u" | head -1 | cut -d= -f2-)"
  [ -n "$PORT" ] || PORT="$(grep -oE '\-\-port[ =]+[0-9]+' "$u" | grep -oE '[0-9]+' | head -1)"
  break
done
for pid in $(pgrep -f "[u]vicorn $MARK" 2>/dev/null); do
  [ "$(app_dir_of "$(readlink "/proc/$pid/cwd" 2>/dev/null)" 2>/dev/null)" = "$APP" ] || continue
  RUN_PID="$pid"
  [ -n "$SVC_USER" ] || SVC_USER="$(ps -o user= -p "$pid" 2>/dev/null | tr -d ' ')"
  [ -n "$PORT" ] || PORT="$(tr '\0' ' ' < "/proc/$pid/cmdline" 2>/dev/null | grep -oE '\-\-port[ =]+[0-9]+' | grep -oE '[0-9]+' | head -1)"
  break
done
PORT="${PORT:-3100}"
OWNER="$(stat -c %U:%G "$APP/webvuln" 2>/dev/null || echo "")"
OLD_VER="$(ver_of "$APP/frontend/config/version.js")"
NEW_VER="$(ver_of "$HERE/files/frontend/config/version.js")"
[ -n "$NEW_VER" ] || NEW_VER="$OLD_VER"

echo "  目標位置： $APP"
echo "  檔案擁有者 ${OWNER:-未知} ｜ 服務 ${UNIT:-（沒有 systemd 服務）} ｜ 執行帳號 ${SVC_USER:-未知} ｜ 埠 $PORT"
echo "  版本　　： ${OLD_VER:-未知} → ${NEW_VER:-未知}"
if [ -n "$OLD_VER" ] && [ "$OLD_VER" = "$NEW_VER" ]; then
  echo "  註：版號相同，這包可能已經套過了。重跑無害，會照樣覆蓋並重啟。"
fi

# ===== 2. 驗包 =====
echo
echo "[2/6] 驗證 patch 內容"
[ -d "$HERE/files" ] || { echo "!! 這包裡沒有 files/，patch 不完整"; exit 1; }
if [ -f "$HERE/SHA256SUMS" ] && command -v sha256sum >/dev/null 2>&1; then
  if (cd "$HERE" && sha256sum -c --quiet SHA256SUMS) >/dev/null 2>&1; then
    echo "  ✓ 包內每個檔的雜湊都對（$(grep -c . "$HERE/SHA256SUMS") 個檔）"
  else
    echo "!! 包內有檔案跟打包時不一樣（傳輸壞掉或被改過），不套用："
    (cd "$HERE" && sha256sum -c SHA256SUMS 2>&1 | grep -v ': OK$' | sed 's/^/     /')
    exit 1
  fi
else
  echo "  - 沒有 SHA256SUMS 或沒有 sha256sum 指令：跳過雜湊驗證（未驗證）"
fi
# DELETE.txt 整份先檢查，全部合規才往下走——檢查到一半才發現有問題的話，
# 前面幾個已經刪了，會留下半套狀態。安全設計（刻意的，不要為了方便放寬）：
#   只接受 $APP 底下的相對路徑；絕對路徑／..／反斜線／~ ＝整個 patch 中止（不是跳過）；
#   符號連結與目錄一律不刪；解析後落在 $APP 之外也中止。
if [ -f "$HERE/DELETE.txt" ]; then
  APP_REAL="$(cd "$APP" && pwd -P)"
  while IFS= read -r rel || [ -n "$rel" ]; do
    rel="${rel%$'\r'}"
    [ -n "$rel" ] || continue
    case "$rel" in \#*) continue ;; esac
    case "$rel" in
      /*|\*|~*|?:*|*\*) echo "!! DELETE.txt 有不安全的路徑，patch 中止： $rel"; exit 1 ;;
    esac
    case "/$rel/" in
      */../*) echo "!! DELETE.txt 的路徑含 ..，patch 中止： $rel"; exit 1 ;;
    esac
    tgt="$APP/$rel"
    par="$(cd "$(dirname "$tgt")" 2>/dev/null && pwd -P)" || par=""
    [ -n "$par" ] || continue                 # 連目錄都不在，本來就沒這個檔
    case "$par/" in
      "$APP_REAL"/*) : ;;
      *) echo "!! DELETE.txt 的目標解析後落在 $APP 之外，patch 中止： $rel → $par"; exit 1 ;;
    esac
    if [ -L "$tgt" ]; then echo "!! $rel 是符號連結，不跟著刪，patch 中止"; exit 1; fi
    if [ -d "$tgt" ]; then echo "!! $rel 是目錄，只刪檔案不刪目錄，patch 中止"; exit 1; fi
  done < "$HERE/DELETE.txt"
  echo "  ✓ 刪除清單檢查通過"
fi
if [ ! -w "$APP/webvuln" ]; then
  echo "!! 目前身分 $(id -un) 寫不進 $APP，請改用： sudo bash patch.sh"
  exit 1
fi
if [ -f "$HERE/MANIFEST.txt" ]; then
  echo "  這包改了什麼："
  sed -n '/== 這包改了什麼 ==/,/^$/p' "$HERE/MANIFEST.txt" | sed '1d;/^$/d' | sed 's/^/    · /'
fi

FILES="$(cd "$HERE/files" && find . -type f | sed 's|^\./||' | sort)"

# ===== 3. 備份（含要刪的檔）=====
echo
echo "[3/6] 備份即將被覆蓋的檔案 → $BACKUP"
mkdir -p "$BACKUP" || { echo "!! 建不出備份目錄，不敢繼續"; exit 1; }
COUNT=0
while IFS= read -r rel; do
  [ -n "$rel" ] || continue
  if [ -f "$APP/$rel" ]; then
    mkdir -p "$BACKUP/$(dirname "$rel")"
    cp -p "$APP/$rel" "$BACKUP/$rel" || { echo "!! 備份 $rel 失敗，不敢繼續"; exit 1; }
    COUNT=$((COUNT+1))
  fi
done <<EOF_FILES
$FILES
EOF_FILES
echo "  已備份 $COUNT 個既有檔案"

# 刪除已廢棄的檔案（清單在 [2/6] 已經整份檢查過，這裡才動手）。刪之前先備份。
PY_CHANGED=0
REQ_CHANGED=0
if [ -f "$HERE/DELETE.txt" ]; then
  echo "  刪除已廢棄的檔案（先備份）"
  DEL_OK=0; DEL_MISS=0
  while IFS= read -r rel || [ -n "$rel" ]; do
    rel="${rel%$'\r'}"
    [ -n "$rel" ] || continue
    case "$rel" in \#*) continue ;; esac
    tgt="$APP/$rel"
    if [ ! -e "$tgt" ]; then DEL_MISS=$((DEL_MISS+1)); continue; fi
    mkdir -p "$BACKUP/$(dirname "$rel")"
    cp -p "$tgt" "$BACKUP/$rel" || { echo "  !! 備份 $rel 失敗，不敢刪，patch 中止"; exit 1; }
    rm -f "$tgt" || { echo "  !! 刪不掉 $rel，patch 中止"; exit 1; }
    case "$rel" in *.py) PY_CHANGED=1 ;; esac
    echo "  ✗ 已刪除 $rel"
    DEL_OK=$((DEL_OK+1))
  done < "$HERE/DELETE.txt"
  echo "  共刪除 $DEL_OK 個檔案（另有 $DEL_MISS 個本來就不在，略過）"
fi

# ===== 4. 覆蓋 =====
# 權限不抄包裡的、也不抄來源的：一律寫成 0644（腳本 0755）。擁有者維持安裝目錄原本那個，
# 不會因為用 root 套用就變成 root 的。
echo
echo "[4/6] 套用新檔案"
FAIL=0
while IFS= read -r rel; do
  [ -n "$rel" ] || continue
  src="$HERE/files/$rel"; dst="$APP/$rel"
  mode=644
  case "$rel" in *.sh) mode=755 ;; esac
  [ "$(head -c 2 "$src" 2>/dev/null)" = '#!' ] && mode=755
  mkdir -p "$(dirname "$dst")" && cp "$src" "$dst.patchnew.$$" || { echo "  !! 寫不進 $rel"; FAIL=1; continue; }
  case "$rel" in
    *.py|*.js|*.html|*.css|*.md|*.sh|*.json|*.txt|*.ini|*.cfg|*.yml|*.yaml|*.sql|*.svg)
      sed -i 's/\r$//' "$dst.patchnew.$$" ;;
  esac
  chmod "$mode" "$dst.patchnew.$$"
  if [ "$(id -u)" = "0" ] && [ -n "$OWNER" ]; then chown "$OWNER" "$dst.patchnew.$$"; fi
  # 先寫到旁邊再換上去：寫到一半失敗不會留下半個檔
  mv -f "$dst.patchnew.$$" "$dst" || { echo "  !! 換不上 $rel"; rm -f "$dst.patchnew.$$"; FAIL=1; continue; }
  case "$rel" in *.py|requirements.txt) PY_CHANGED=1 ;; esac
  case "$rel" in requirements.txt) REQ_CHANGED=1 ;; esac
  echo "  ✓ $rel"
done <<EOF_FILES
$FILES
EOF_FILES
if [ "$(id -u)" = "0" ] && [ -n "$OWNER" ]; then chown -R "$OWNER" "$BACKUP" 2>/dev/null; fi

# 用「服務實際執行的帳號」確認讀得到。用 root 驗一定過，那個驗證是假的。
if [ "$FAIL" = "0" ] && [ "$(id -u)" = "0" ] && [ -n "$SVC_USER" ] && [ "$SVC_USER" != "root" ] \
   && id "$SVC_USER" >/dev/null 2>&1 && command -v runuser >/dev/null 2>&1; then
  # 只有服務執行時真的會讀的（webvuln/、frontend/）讀不到才算失敗；
  # deploy/ 這類安裝腳本讀不到只提醒——那通常是安裝目錄本來的權限，不是這包造成的。
  UNREAD=0; UNREAD_WARN=0
  while IFS= read -r rel; do
    [ -n "$rel" ] || continue
    runuser -u "$SVC_USER" -- test -r "$APP/$rel" 2>/dev/null && continue
    # 找出是哪一層擋住的，直接講出來，不要讓人自己猜
    blk="$APP/$rel"; d="$APP"
    IFS=/ read -ra parts <<< "$(dirname "$rel")"
    for part in "${parts[@]}"; do
      [ "$part" = "." ] && continue
      d="$d/$part"
      runuser -u "$SVC_USER" -- test -x "$d" 2>/dev/null || { blk="$d"; break; }
    done
    case "$rel" in
      webvuln/*|frontend/*)
        echo "  !! 帳號 $SVC_USER 讀不到 $rel（擋在 $blk，權限 $(stat -c '%a %U:%G' "$blk")）"; UNREAD=1 ;;
      *)
        echo "  ⚠ 帳號 $SVC_USER 讀不到 $rel（擋在 $blk，權限 $(stat -c '%a %U:%G' "$blk")）——服務執行用不到這個檔，不影響"; UNREAD_WARN=1 ;;
    esac
  done <<EOF_FILES
$FILES
EOF_FILES
  if [ "$UNREAD" = "1" ]; then
    echo "     服務會因為讀不到程式而起不來。請修正上面那一層的權限後重跑這支腳本。"
    FAIL=1
  else
    echo "  ✓ 已用服務帳號 $SVC_USER 確認服務要用的檔都讀得到"
  fi
elif [ "$FAIL" = "0" ]; then
  echo "  - 沒有另外用服務帳號驗證讀取權限（不是 root 執行，或查不到服務帳號）"
fi

# ===== 4.5 更新相依（requirements 變了才做；優先用 offline_wheels 離線裝）=====
if [ "$FAIL" = "0" ] && [ "$REQ_CHANGED" = "1" ]; then
  echo
  echo "[4.5] requirements 有變，更新相依"
  VENV=""
  for d in "$APP" "$APP/.." "$APP/../.."; do
    [ -x "$d/.venv/bin/python" ] && { VENV="$(cd "$d" && pwd -P)/.venv"; break; }
  done
  if [ -z "$VENV" ]; then
    echo "  ⚠ 找不到 .venv，略過自動安裝——請自行把新相依裝進虛擬環境"
  else
    PIP="$VENV/bin/pip"
    if [ -d "$APP/offline_wheels" ] && ls "$APP/offline_wheels"/*.whl >/dev/null 2>&1; then
      echo "  離線：用 offline_wheels 安裝（不連網）"
      "$PIP" install --no-index --find-links "$APP/offline_wheels" -r "$APP/requirements.txt" 2>&1 | sed 's/^/    /' | tail -6 \
        || { echo "  !! 離線安裝失敗，服務可能缺套件"; FAIL=1; }
    else
      echo "  線上：pip 安裝"
      "$PIP" install -r "$APP/requirements.txt" 2>&1 | sed 's/^/    /' | tail -6 \
        || { echo "  !! 安裝失敗，服務可能缺套件"; FAIL=1; }
    fi
  fi
fi

# ===== 5. 重啟 =====
# 後端是常駐的 uvicorn，不重啟就還在跑記憶體裡的舊程式，檔案換了也沒用。
echo
echo "[5/6] 讓新程式生效"
PENDING=0
if [ "$FAIL" != "0" ]; then
  echo "  - 前面有失敗，不重啟"
elif [ -n "$UNIT" ]; then
  SC="systemctl"
  [ "$(id -u)" = "0" ] || SC="sudo -n systemctl"
  echo "  重啟 $UNIT（最多等 60 秒）…"
  if command -v timeout >/dev/null 2>&1; then
    timeout 60 $SC restart "$UNIT" 2>&1 | sed 's/^/    /'; RC=${PIPESTATUS[0]}
  else
    $SC restart "$UNIT" 2>&1 | sed 's/^/    /'; RC=${PIPESTATUS[0]}
  fi
  if [ "$RC" != "0" ]; then
    echo "  !! 重啟失敗（不是 root 的話請改用 sudo bash patch.sh）"; FAIL=1
  fi
elif [ -n "$RUN_PID" ]; then
  if [ "$PY_CHANGED" = "1" ]; then
    PENDING=1
    echo "  ⚠ 這台不是 systemd 服務，是手動啟動的行程（PID $RUN_PID）。"
    echo "    這包有改後端程式，我不會替你殺行程——請自己停掉後重新啟動，新程式才會生效："
    echo "      kill $RUN_PID    然後用原本的方式重新啟動（例如 bash run.sh）"
    [ -f "$APP/deploy/install-service.sh" ] && {
      echo "    或者直接改成 systemd 服務（會自己停掉舊行程、用專用帳號起新的）："
      echo "      sudo bash $APP/deploy/install-service.sh"; }
  else
    echo "  ✓ 這包只改前端檔，不用重啟（瀏覽器按 Ctrl+F5）"
  fi
else
  echo "  - 服務目前沒有在跑，也沒有 systemd 服務。啟動後就是新版。"
fi

# ===== 6. 驗證 =====
echo
echo "[6/6] 驗證"
VERIFIED=0
if [ "$FAIL" != "0" ]; then
  echo "  - 前面有失敗，略過"
elif [ -z "$UNIT" ] && [ -z "$RUN_PID" ]; then
  echo "  - 服務沒在跑，沒辦法驗證（未驗證）"
elif [ "$PENDING" = "1" ]; then
  echo "  - 後端還是舊行程，現在打 health 只會得到舊程式的回應，不算數（未驗證）"
elif ! command -v curl >/dev/null 2>&1; then
  echo "  - 這台沒有 curl，沒辦法驗證（未驗證）。請用瀏覽器開 http://這台:$PORT 看版號"
else
  HEALTH=""
  for i in 1 2 3 4 5 6 7 8 9 10 11 12 13 14 15; do
    HEALTH="$(curl -s -m 3 "http://127.0.0.1:$PORT/api/health" 2>/dev/null)"
    case "$HEALTH" in *ok*) break ;; esac
    sleep 1
  done
  case "$HEALTH" in
    *ok*) echo "  ✓ 後端有回應（/api/health）" ;;
    *)    echo "  !! 後端 15 秒內沒有回應（埠 $PORT）"; FAIL=1 ;;
  esac
  if [ -n "$UNIT" ]; then
    if systemctl is-active --quiet "$UNIT"; then
      echo "  ✓ $UNIT active"
    else
      echo "  !! $UNIT 沒起來："; journalctl -u "$UNIT" -n 25 --no-pager 2>/dev/null | tail -15 | sed 's/^/     /'
      FAIL=1
    fi
  fi
  if [ "$FAIL" = "0" ]; then
    SERVED="$(curl -s -m 3 "http://127.0.0.1:$PORT/config/version.js" 2>/dev/null | grep -oE "APP_VERSION *= *'V?[0-9.]+'" | grep -oE '[0-9]+(\.[0-9]+)+' | head -1)"
    if [ -z "$NEW_VER" ]; then
      echo "  - 讀不到這版的版號，沒辦法比對（服務送出的是「${SERVED:-讀不到}」）"; VERIFIED=1
    elif [ "$SERVED" = "$NEW_VER" ]; then
      echo "  ✓ 服務實際送出的版號是 $SERVED"; VERIFIED=1
    else
      echo "  !! 服務送出的版號是「${SERVED:-讀不到}」，預期 $NEW_VER"; FAIL=1
    fi
  fi
fi

if [ "$FAIL" != "0" ]; then RESULT="失敗"; elif [ "$PENDING" = "1" ]; then RESULT="檔案已換、後端待重啟"
elif [ "$VERIFIED" = "1" ]; then RESULT="成功"; else RESULT="檔案已換、未驗證"; fi
TO_COMMIT="$(grep -E '^版本範圍' "$HERE/MANIFEST.txt" 2>/dev/null | head -1 | sed 's/^[^：]*： *//')"
echo "$(date '+%F %T') $(basename "$HERE") ${OLD_VER:-?}→${NEW_VER:-?} commit[${TO_COMMIT:-?}] by $(id -un) 結果:$RESULT 備份:$BACKUP" >> "$HISTORY" 2>/dev/null

echo
echo "════════════════════════════════════════════════"
if [ "$FAIL" != "0" ]; then
  echo "!! 沒有完成 —— 上面標 !! 的那幾行就是原因"
  echo "   要還原成套用前的狀態： cp -a $BACKUP/. $APP/"
  [ -n "$UNIT" ] && echo "   然後： systemctl restart $UNIT"
  echo "   查不出來就把整個畫面貼回給開發者。"
  RC=1
elif [ "$PENDING" = "1" ]; then
  echo "⚠ 檔案已換成 $NEW_VER，但後端還在跑舊程式 —— 照 [5/6] 的說明重新啟動才算完成"
  RC=3
elif [ "$VERIFIED" = "1" ]; then
  echo "✅ patch 完成：版本 ${OLD_VER:-未知} → $NEW_VER，服務已在跑"
  echo "   瀏覽器請按 Ctrl+F5，右上角版號應該是 V$NEW_VER"
  RC=0
else
  echo "✅ 檔案已換成 $NEW_VER（服務狀態未驗證，原因見 [6/6]）"
  RC=0
fi
echo "   備份： $BACKUP"
echo "   紀錄： $HISTORY"
echo "════════════════════════════════════════════════"
exit $RC
